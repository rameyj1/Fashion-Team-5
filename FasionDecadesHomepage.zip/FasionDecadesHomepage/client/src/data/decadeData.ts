export const decadeData = [
  {
    id: "1970s",
    title: "1970s Fashion",
    subtitle: "The Bohemian Era",
    description: "Bell-bottoms, platform shoes, and disco influences defined this vibrant decade of self-expression.",
    imageUrl: "/images/70s.jpg"
  },
  {
    id: "1980s",
    title: "1980s Fashion",
    subtitle: "The Power Decade",
    description: "Shoulder pads, neon colors, and power suits characterized this bold era of excess and ambition.",
    imageUrl: "https://images.unsplash.com/photo-1517230878791-4d28214057c2?q=80&w=2069"
  },
  {
    id: "1990s",
    title: "1990s Fashion",
    subtitle: "The Grunge & Minimalism",
    description: "Flannel shirts, slip dresses, and an attitude of rebellion and stripped-down simplicity.",
    imageUrl: "/images/90s.jpg"
  },
  {
    id: "2000s",
    title: "2000s Fashion",
    subtitle: "Y2K & Digital Age",
    description: "Low-rise jeans, velour tracksuits, and the fusion of technology with fashion aesthetics.",
    imageUrl: "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?q=80&w=2071"
  }
];
