import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { decadeData } from "@/data/decadeData";

export default function Decade() {
  const { id } = useParams();
  const [_, setLocation] = useLocation();
  const [decade, setDecade] = useState<any>(null);

  useEffect(() => {
    const currentDecade = decadeData.find(d => d.id === id);
    if (currentDecade) {
      setDecade(currentDecade);
      document.title = `${currentDecade.title} Fashion | StyleChronicle`;
    } else {
      setLocation("/");
    }
  }, [id, setLocation]);

  if (!decade) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-2xl">Loading...</div>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-[#f8f8f8] py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold mb-8 text-[#7b1e34] font-['Playfair_Display']">
            {decade.title}
          </h1>
          <p className="mb-6 text-lg">
            This is a placeholder for the {decade.title} page. In a complete implementation, 
            this page would contain detailed information about fashion trends, influential designers, 
            iconic pieces, and cultural contexts that shaped fashion during this decade.
          </p>
          <button 
            onClick={() => setLocation("/")}
            className="bg-[#161c3a] hover:bg-opacity-90 text-white font-medium py-2 px-6 rounded-md transition-all duration-300"
          >
            Back to Home
          </button>
        </div>
      </div>
    </main>
  );
}
