import { useEffect } from "react";
import HeroBanner from "@/components/HeroBanner";
import Introduction from "@/components/Introduction";
import DecadesSection from "@/components/DecadesSection";
import AboutSection from "@/components/AboutSection";
import NewsletterSection from "@/components/NewsletterSection";

export default function Home() {
  useEffect(() => {
    document.title = "StyleChronicle | Fashion Through Time";
  }, []);

  return (
    <main className="min-h-screen bg-[#f8f8f8]">
      <HeroBanner />
      <Introduction />
      <DecadesSection />
      <AboutSection />
      <NewsletterSection />
    </main>
  );
}
