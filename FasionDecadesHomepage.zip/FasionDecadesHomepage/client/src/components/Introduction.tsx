export default function Introduction() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#7b1e34] font-['Playfair_Display']">Fashion Through Time</h2>
          <p className="mb-6 text-lg leading-relaxed">Fashion is more than clothing—it's a reflection of society, culture, and individual expression. Each decade brings unique trends, revolutionary styles, and iconic looks that define an era.</p>
          <p className="mb-6 text-lg leading-relaxed">From the free-spirited bohemian styles of the 1970s to the grunge and minimalism of the 1990s, our journey through fashion history highlights how clothing has evolved alongside social movements, technological advancements, and cultural shifts.</p>
          <p className="text-lg leading-relaxed">Select a decade below to dive into the distinctive styles, influential designers, and cultural contexts that shaped fashion's evolution.</p>
        </div>
      </div>
    </section>
  );
}
