import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import RetroLogo from "./RetroLogo";

export default function Header() {
  const [location] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className={`retro-header ${isScrolled ? 'shadow-md' : 'shadow-sm'} sticky top-0 z-50 transition-shadow duration-300`}>
      <div className="retro-container py-4 flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <RetroLogo width={200} height={90} className="mr-4" />
              <div className="flex flex-col ml-2">
                <div className="retro-logo text-2xl md:text-3xl">Trends</div>
                <div className="retro-subtitle text-sm text-center">over decades</div>
              </div>
            </div>
          </Link>
        </div>
        
        <nav className="w-full md:w-auto">
          <ul className="retro-nav flex-wrap justify-center">
            <li>
              <Link href="/">
                <div className={`retro-nav-link ${location === '/' ? 'active' : ''}`}>
                  Home
                </div>
              </Link>
            </li>
            <li>
              <a href={location === '/' ? '#decades' : '/#decades'} 
                 className="retro-nav-link">
                Decades
              </a>
            </li>
            <li>
              <a href={location === '/' ? '#about' : '/#about'} 
                 className="retro-nav-link">
                About
              </a>
            </li>
            <li>
              <a href={location === '/' ? '#newsletter' : '/#newsletter'} 
                 className="retro-nav-link">
                Newsletter
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
