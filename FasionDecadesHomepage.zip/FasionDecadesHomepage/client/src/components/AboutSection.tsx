import { Button } from "@/components/ui/button";

export default function AboutSection() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center max-w-5xl mx-auto">
          <div className="md:w-1/2 md:pr-12 mb-8 md:mb-0">
            <img src="/images/about-logo.jpg" alt="Trends over Decades Logo" className="rounded-lg shadow-lg w-full h-auto" />
          </div>
          <div className="md:w-1/2">
            <h2 className="text-3xl font-bold mb-6 text-[#7b1e34] font-['Playfair_Display']">About Our Project</h2>
            <p className="mb-4 leading-relaxed">StyleChronicle is dedicated to exploring and documenting the rich history of fashion across decades. Our team of fashion historians, designers, and cultural analysts work together to provide accurate, engaging content about style evolution.</p>
            <p className="mb-6 leading-relaxed">We believe that understanding fashion history helps us appreciate current trends and anticipate future directions in the world of style and design.</p>
            <div className="flex space-x-4">
              <Button className="bg-[#161c3a] hover:bg-opacity-90 text-white font-medium py-2 px-6 rounded-md transition-all duration-300 text-sm">
                Our Team
              </Button>
              <Button variant="outline" className="bg-transparent border border-[#7b1e34] text-[#7b1e34] hover:bg-[#7b1e34] hover:text-white font-medium py-2 px-6 rounded-md transition-all duration-300 text-sm">
                Contact Us
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
