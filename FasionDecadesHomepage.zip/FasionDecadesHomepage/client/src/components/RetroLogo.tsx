import React from 'react';

interface RetroLogoProps {
  className?: string;
  width?: number;
  height?: number;
}

export default function RetroLogo({ className = '', width = 300, height = 300 }: RetroLogoProps) {
  return (
    <div className={`relative ${className}`}>
      <img 
        src="/images/logo.jpg" 
        alt="Trends over Decades Logo" 
        width={width} 
        height={height}
        className="retro-wiggle"
        style={{ 
          maxWidth: '100%', 
          height: 'auto',
          objectFit: 'contain',
          borderRadius: '5px',
          filter: 'drop-shadow(3px 3px 0 rgba(72, 39, 86, 0.5))'
        }}
      />
    </div>
  );
}