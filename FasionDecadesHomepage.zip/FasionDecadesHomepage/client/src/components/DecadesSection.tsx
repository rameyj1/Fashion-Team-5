import { Link } from "wouter";
import { decadeData } from "@/data/decadeData";

export default function DecadesSection() {
  return (
    <section id="decades" className="py-16 bg-[#e9e9e9]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center font-['Playfair_Display']">Explore By Decade</h2>
        <p className="text-lg text-center max-w-3xl mx-auto mb-12">Click on a decade to discover the defining styles, iconic fashion moments, and cultural influences.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {decadeData.map((decade) => (
            <Link key={decade.id} href={`/decade/${decade.id}`}>
              <a className="group bg-white rounded-lg overflow-hidden shadow-md transition-all duration-300 hover:transform hover:-translate-y-1 hover:shadow-xl">
                <div className={`h-48 bg-[url('${decade.imageUrl}')] bg-cover bg-center relative`}>
                  <div className={`absolute inset-0 bg-${decade.id === '1970s' || decade.id === '1990s' ? '[#7b1e34]' : '[#161c3a]'} bg-opacity-50 group-hover:bg-opacity-30 transition-all duration-300`}></div>
                  <div className="absolute bottom-0 left-0 w-full p-4">
                    <span className="inline-block text-white text-4xl font-bold font-['Montserrat']">{decade.id}</span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2 font-['Playfair_Display']">{decade.subtitle}</h3>
                  <p className="text-[#333333]">{decade.description}</p>
                  <div className="mt-4 flex justify-between items-center">
                    <span className="text-[#7b1e34] font-medium">Explore more</span>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#d4af37] group-hover:translate-x-1 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                  </div>
                </div>
              </a>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
