import { Link } from "wouter";
import { decadeData } from "@/data/decadeData";

export default function DecadesSection() {
  // Function to get retro card class based on decade
  const getDecadeClass = (decade: string) => {
    switch(decade) {
      case '1960s': return 'retro-card-60s';
      case '1970s': return 'retro-card-70s';
      case '1980s': return 'retro-card-80s';
      case '1990s': return 'retro-card-90s';
      case '2000s': return 'retro-card-00s';
      default: return '';
    }
  };
  
  // Function to get starburst class based on decade
  const getStarburstClass = (decade: string) => {
    switch(decade) {
      case '1960s': return 'decade-60s';
      case '1970s': return 'decade-70s';
      case '1980s': return 'decade-80s';
      case '1990s': return 'decade-90s';
      case '2000s': return 'decade-00s';
      default: return '';
    }
  };

  return (
    <section id="decades" className="retro-section retro-section-cream">
      <div className="retro-container">
        <div className="retro-section-title">
          <h2 className="retro-title text-3xl md:text-4xl tilt-left">Explore By Decade</h2>
          <p className="text-xl text-center max-w-3xl mx-auto mt-4 mb-12 text-retro-purple">
            Click on a decade to discover the defining styles, iconic fashion moments, and cultural influences.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {decadeData.map((decade) => (
            <Link key={decade.id} href={`/decade/${decade.id}`}>
              <div className={`retro-card ${getDecadeClass(decade.id)} cursor-pointer`}>
                <div className="retro-card-img relative bg-retro-cream" 
                     style={{height: '200px'}}> {/* Use a fixed height instead of backgroundImage */}
                  <img 
                    src={decade.imageUrl} 
                    alt={`${decade.id} fashion`}
                    className="absolute inset-0 w-full h-full object-cover"
                    onError={(e) => {
                      // If image fails to load, set a decade-specific fallback background color
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      (target.parentElement as HTMLElement).style.backgroundColor = 
                        decade.id === '1970s' ? '#E55B89' : 
                        decade.id === '1980s' ? '#30BEBC' : 
                        decade.id === '1990s' ? '#9D7ABF' : '#F4A742';
                    }}
                  />
                  <div className="retro-card-overlay absolute inset-0"></div>
                  <div className={`retro-card-decade ${getStarburstClass(decade.id)} z-10`}>
                    {decade.id.substring(0, 4)}
                  </div>
                </div>
                <div className="retro-card-content">
                  <h3 className="retro-card-title">{decade.subtitle}</h3>
                  <p>{decade.description}</p>
                  <div className="mt-4 flex justify-between items-center">
                    <span className="card-link-text font-medium text-retro-purple">Explore more</span>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-retro-orange" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
