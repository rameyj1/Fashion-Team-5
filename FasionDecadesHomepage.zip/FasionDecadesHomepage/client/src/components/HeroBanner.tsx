import { Button } from "@/components/ui/button";

export default function HeroBanner() {
  const scrollToDecades = () => {
    const decadesSection = document.getElementById('decades');
    if (decadesSection) {
      window.scrollTo({
        top: decadesSection.offsetTop - 100,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="bg-[#161c3a] text-white py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=2070')] bg-cover bg-center opacity-20"></div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 font-['Playfair_Display']">Fashion Evolution Through the Decades</h1>
          <p className="text-lg md:text-xl mb-10 font-light">Explore how style has transformed from the vibrant 70s to the digital 2000s</p>
          <Button
            onClick={scrollToDecades}
            className="bg-[#7b1e34] hover:bg-opacity-90 text-white font-medium py-3 px-8 rounded-md transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            Start Exploring
          </Button>
        </div>
      </div>
    </section>
  );
}
