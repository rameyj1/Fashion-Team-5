import RetroLogo from "./RetroLogo";

export default function HeroBanner() {
  const scrollToDecades = () => {
    const decadesSection = document.getElementById('decades');
    if (decadesSection) {
      window.scrollTo({
        top: decadesSection.offsetTop - 100,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="retro-hero">
      <div className="retro-container relative z-10">
        <div className="retro-hero-content">
          <div className="mb-10 flex justify-center">
            <RetroLogo width={350} height={350} />
          </div>
          <h1 className="retro-title text-4xl md:text-5xl lg:text-6xl mb-6">Fashion Evolution Through Time</h1>
          <p className="text-xl mb-10 text-retro-purple">Explore how style has transformed from the vibrant 60s to the digital 2000s</p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <div className="starburst decade-tag-60s">60s</div>
            <div className="starburst decade-tag-70s">70s</div>
            <div className="starburst decade-tag-80s">80s</div>
            <div className="starburst decade-tag-90s">90s</div>
            <div className="starburst decade-tag-00s">00s</div>
          </div>
          
          <button
            onClick={scrollToDecades}
            className="retro-btn retro-btn-pink retro-wiggle"
          >
            Start Exploring
          </button>
        </div>
      </div>
    </section>
  );
}
